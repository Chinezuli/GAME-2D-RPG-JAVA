#include"Game.h"
#include<map>
int main()
{
    Game game;
    game.run();
    return 0;
}