#ifndef GAMESTATE_H
#define GAMESTATE_H
#include "GameState.h"
class GameState :
    public State
{
private:
public:
    GameState(sf::RenderWindow* window);
    virtual ~GameState();
    //Functions

    void endState();
    void update();
    void render();
};
#endif

